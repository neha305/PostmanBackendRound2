package users

import (
	"database/sql"
	"errors"
	"fmt"
	"log"

	_ "github.com/go-sql-driver/mysql"
	"golang.org/x/crypto/bcrypt"
)

type User struct {
	Uname string
	Psw   string
}

type authUser struct {
	uname     string
	pwdHash   string
	followers int
	following int
}

var DefaultUserService (userService)

type userService struct {
}

var db *sql.DB
var err error

func (userService) VerifyUser(user User) int {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	fmt.Println("Db connected")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}
	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}
	var storedPassword string
	err = db.QueryRow("SELECT PassWord FROM Profiles WHERE UserName = ?", user.Uname).Scan(&storedPassword)

	if err != nil {
		if err == sql.ErrNoRows {
			return 2
		} else {
			log.Fatal(err)
		}
		//Username not found
		return 2
	}

	err = bcrypt.CompareHashAndPassword([]byte(storedPassword), []byte(user.Psw))
	if err == nil {
		return 1
		//All good
	} else {
		return 0
		//Wrong password
	}
}

func (userService) CreateUser(newUser User) error {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}
	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}
	pres, err := valueExists(db, "Profiles", "UserName", newUser.Uname)
	if err != nil {
		panic(err)
	}
	if pres {
		return errors.New("username already exists")
	} else {
		fmt.Println("Searched")
	}

	pwdHash, err := getPasswordHash(newUser.Psw)
	if err != nil {
		return err
	}
	newAuthUser := authUser{
		uname:     newUser.Uname,
		pwdHash:   pwdHash,
		followers: 0,
		following: 0,
	}

	stmt, err := db.Prepare("INSERT INTO `Profiles` (`UserName`, `PassWord`, `Followers`, `Following`) VALUES (?, ?, ?, ?)")
	if err != nil {
		panic(err)
	}
	defer stmt.Close()

	_, err = stmt.Exec(newAuthUser.uname, newAuthUser.pwdHash, newAuthUser.followers, newAuthUser.following)
	if err != nil {
		panic(err)
	}

	fmt.Println("Inserted")
	return nil
}

func getPasswordHash(password string) (string, error) {
	hash, err := bcrypt.GenerateFromPassword([]byte(password), 0)
	return string(hash), err
}

func valueExists(db *sql.DB, tableName string, columnName string, value string) (bool, error) {
	var exists bool
	err := db.QueryRow("SELECT EXISTS (SELECT 1 FROM "+tableName+" WHERE "+columnName+" = ?)", value).Scan(&exists)
	if err != nil {
		return false, err
	}
	fmt.Println(exists)
	return exists, nil
}
