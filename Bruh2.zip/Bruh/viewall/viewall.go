package viewall

import (
	"database/sql"
	"fmt"
	"html/template"
	"net/http"

	_ "github.com/go-sql-driver/mysql"
)

var db *sql.DB
var err error

func ViewAll(w http.ResponseWriter, r *http.Request, uname string) {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	fmt.Println("Db connected")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	rows, err := db.Query("SELECT UserName FROM Profiles")
	if err != nil {
		panic(err.Error())
	}
	defer rows.Close()

	var columnValues []string

	for rows.Next() {
		var value string

		if err := rows.Scan(&value); err != nil {
			panic(err.Error())
		}
		if value == uname {
			continue
		}
		columnValues = append(columnValues, value)
	}

	if err := rows.Err(); err != nil {
		panic(err.Error())
	}

	data := struct {
		People []string
		Text   string
	}{
		People: columnValues,
		Text:   "All Users",
	}

	tmpl := template.Must(template.ParseFiles("Templates/AllPeeps.html"))

	err = tmpl.Execute(w, data)
	if err != nil {
		panic(err)
	}
}
