package profile

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"html/template"
	"io"
	"log"
	"net/http"

	"os"

	_ "github.com/go-sql-driver/mysql"
)

type PageData struct {
	Name          string
	Followers     int
	Following     int
	WholeSomeNote string
	Show          bool
	Path          string
	PsShow        bool
	Posts         []string
}

type OPageData struct {
	Name          string
	Followers     int
	Following     int
	WholeSomeNote string
	Show          bool
	PShow         bool
	Path          string
	PsShow        bool
	Posts         []string
}

var db *sql.DB
var err error

func Setting(w http.ResponseWriter, r *http.Request, uname string) {
	var show bool
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	rows, err := db.Query("SELECT Followers, Following, PfpYes, pfpPath FROM Profiles WHERE UserName = ?", uname)
	if err != nil {
		panic(err.Error())
	}
	defer rows.Close()

	var followers, following int
	var path string
	for rows.Next() {
		if err := rows.Scan(&followers, &following, &show, &path); err != nil {
			panic(err.Error())
		}

		if err := rows.Err(); err != nil {
			panic(err.Error())
		}
	}
	show = !show
	path = "/" + path

	var posts int
	err = db.QueryRow("SELECT Posts FROM Profiles WHERE UserName = ? LIMIT 1", uname).Scan(&posts)

	var paths []string

	if posts != 0 {
		rows, err := db.Query("SELECT Path FROM Posts WHERE UserName = ?", uname)
		if err != nil {
			log.Fatal(err)
		}
		defer rows.Close()

		for rows.Next() {
			var columnValue /*, column2Value*/ string
			if err := rows.Scan(&columnValue /*, &column2Value*/); err != nil {
				log.Fatal(err)
			}
			paths = append(paths, "/"+columnValue)
		}
	}

	data := PageData{
		Name:          uname,
		Followers:     followers,
		Following:     following,
		WholeSomeNote: "",
		Show:          show,
		Path:          path,
		PsShow:        (posts != 0),
		Posts:         paths,
	}

	if followers == 0 {
		data.WholeSomeNote = "Sed lyf you have -_-"
	}
	fmt.Println(show)

	tmpl, err := template.ParseFiles("Templates/MyProfile.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	err = tmpl.Execute(w, data)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

func Upload(w http.ResponseWriter, r *http.Request, uname string) {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	fmt.Println("Uploading")
	r.ParseMultipartForm(10 << 20)
	file, handler, err := r.FormFile("myFile")
	if err != nil {
		fmt.Println("Retrieving BT")
		return
	}
	defer file.Close()

	f, err := os.OpenFile("PfpS/"+handler.Filename, os.O_WRONLY|os.O_CREATE, 0666)
	if err != nil {
		http.Error(w, "Error creating file", http.StatusInternalServerError)
		return
	}
	defer f.Close()

	_, err = io.Copy(f, file)
	if err != nil {
		http.Error(w, "Error copying file", http.StatusInternalServerError)
		return
	}

	query := "UPDATE Profiles SET pfpPath = ? WHERE UserName = ?"

	_, err = db.Exec(query, "PfpS/"+handler.Filename, uname)

	query = "UPDATE Profiles SET PfpYes = ? WHERE UserName = ?"

	_, err = db.Exec(query, true, uname)

	if err != nil {
		fmt.Println("Error updating column value:", err)
		return
	}
}

func OSetting(w http.ResponseWriter, r *http.Request, lname string, cname string) {
	show := true
	var ps bool
	var path string
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}
	var fing, fer int
	err = db.QueryRow("SELECT Following FROM Profiles WHERE UserName = ? LIMIT 1", lname).Scan(&fing)
	err = db.QueryRow("SELECT Followers FROM Profiles WHERE UserName = ? LIMIT 1", cname).Scan(&fer)
	if fing != 0 && fer != 0 {
		var fersl string
		err = db.QueryRow("SELECT FollowersList FROM Profiles WHERE UserName = ? LIMIT 1", cname).Scan(&fersl)
		var fersL []string
		err = json.Unmarshal([]byte(fersl), &fersL)
		if err != nil {
			panic(err.Error())
		}
		if contains(fersL, lname) {
			show = false
		}
	}
	err = db.QueryRow("SELECT Following FROM Profiles WHERE UserName = ? LIMIT 1", cname).Scan(&fing)
	err = db.QueryRow("SELECT PfpYes FROM Profiles WHERE UserName = ? LIMIT 1", cname).Scan(&ps)
	err = db.QueryRow("SELECT pfpPath FROM Profiles WHERE UserName = ? LIMIT 1", cname).Scan(&path)

	var posts int
	err = db.QueryRow("SELECT Posts FROM Profiles WHERE UserName = ? LIMIT 1", cname).Scan(&posts)
	var paths []string

	if posts != 0 {
		rows, err := db.Query("SELECT Path FROM Posts WHERE UserName = ?", cname)
		if err != nil {
			log.Fatal(err)
		}
		defer rows.Close()

		for rows.Next() {
			var columnValue /*, column2Value*/ string
			if err := rows.Scan(&columnValue /*, &column2Value*/); err != nil {
				log.Fatal(err)
			}
			paths = append(paths, "/"+columnValue)
		}
	}

	path = "/" + path
	data := OPageData{
		Name:          cname,
		Followers:     fer,
		Following:     fing,
		WholeSomeNote: "",
		Show:          show,
		PShow:         ps,
		Path:          path,
		PsShow:        (posts != 0),
		Posts:         paths,
	}
	tmpl, err := template.ParseFiles("Templates/OtherProfile.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	err = tmpl.Execute(w, data)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}

func contains(s []string, str string) bool {
	for _, v := range s {
		if v == str {
			return true
		}
	}
	return false
}
