package doingshit

import (
	"database/sql"
	"encoding/json"
	"fmt"

	"html/template"
	"io"
	"net/http"
	"os"
	"strings"

	_ "github.com/go-sql-driver/mysql"
)

var db *sql.DB
var err error

type PostData struct {
	Path     string
	Likes    int
	Comments int
	CommList []string
	CShow    bool
	Names    []string
	Tags     string
}

type OPostData struct {
	Path     string
	Likes    int
	Comments int
	CommList []string
	CShow    bool
	Names    []string
	Tags     string
	LShow    bool
}

type SearchData struct {
	Paths []string
	Names []string
	Tag   string
	Show  bool
}

func Follow(w http.ResponseWriter, r *http.Request, lname string, cname string) {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	var fers, fing int
	err = db.QueryRow("SELECT Following FROM Profiles WHERE UserName = ? LIMIT 1", lname).Scan(&fing)
	err = db.QueryRow("SELECT Followers FROM Profiles WHERE UserName = ? LIMIT 1", cname).Scan(&fers)

	var forList []string
	var fogList []string
	var JSONstring string

	if fers != 0 {
		err = db.QueryRow("SELECT FollowersList FROM Profiles WHERE UserName = ? LIMIT 1", cname).Scan(&JSONstring)
		err = json.Unmarshal([]byte(JSONstring), &forList)
	}
	forList = append(forList, lname)

	if fing != 0 {
		err = db.QueryRow("SELECT FollowingList FROM Profiles WHERE UserName = ? LIMIT 1", lname).Scan(&JSONstring)
		err = json.Unmarshal([]byte(JSONstring), &fogList)
	}
	fogList = append(fogList, cname)

	fing++
	fers++
	query := "UPDATE Profiles SET Followers = ? WHERE UserName = ?"
	_, err = db.Exec(query, fers, cname)
	query = "UPDATE Profiles SET Following = ? WHERE UserName = ?"
	_, err = db.Exec(query, fing, lname)
	jsonData, err := json.Marshal(forList)
	query = "UPDATE Profiles SET FollowersList = ? WHERE UserName = ?"
	_, err = db.Exec(query, jsonData, cname)
	jsonData, err = json.Marshal(fogList)
	query = "UPDATE Profiles SET FollowingList = ? WHERE UserName = ?"
	_, err = db.Exec(query, jsonData, lname)
}

func NewPost(w http.ResponseWriter, r *http.Request, uname string) {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	fmt.Println("Uploading")
	r.ParseMultipartForm(10 << 20)
	file, handler, err := r.FormFile("myFile")
	if err != nil {
		fmt.Println("Retrieving BT")
		return
	}
	defer file.Close()

	f, err := os.OpenFile("Posts/"+handler.Filename, os.O_WRONLY|os.O_CREATE, 0666)
	if err != nil {
		http.Error(w, "Error creating file", http.StatusInternalServerError)
		return
	}
	defer f.Close()

	_, err = io.Copy(f, file)
	if err != nil {
		http.Error(w, "Error copying file", http.StatusInternalServerError)
		return
	}

	tags := r.Form.Get("tags")
	tagsA := strings.Split(tags, ",")
	for i, str := range tagsA {
		tagsA[i] = strings.TrimSpace(str)
	}
	tagsJ, err := json.Marshal(tagsA)
	var posts int
	err = db.QueryRow("SELECT Posts FROM Profiles WHERE UserName = ? LIMIT 1", uname).Scan(&posts)
	posts++
	query := "UPDATE Profiles SET Posts = ? WHERE UserName = ?"
	_, err = db.Exec(query, posts, uname)

	query = "INSERT INTO Posts (UserName, Path, Tags) VALUES (?, ?, ?)"
	_, err = db.Exec(query, uname, "Posts/"+handler.Filename, tagsJ)

	if err != nil {
		fmt.Println("Error updating tables", err)
		return
	}
}

func ViewMyPost(w http.ResponseWriter, r *http.Request, path string, uname string) {
	fmt.Println("In func " + path)
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	var likes, comments int
	var comlJ, namlJ, tagJ string
	err = db.QueryRow("SELECT CommNo, Likes, Comments, CommentBy FROM Posts WHERE UserName = ? AND Path = ? LIMIT 1", uname, path).Scan(&comments, &likes, &comlJ, &namlJ)
	err = db.QueryRow("SELECT Tags FROM Posts WHERE UserName = ? AND Path = ?", uname, path).Scan(&tagJ)

	var comL, namL, tagL []string
	if comments != 0 {
		err = json.Unmarshal([]byte(comlJ), &comL)
		err = json.Unmarshal([]byte(namlJ), &namL)
	}
	err = json.Unmarshal([]byte(tagJ), &tagL)
	tagC := strings.Join(tagL, ",")

	data := PostData{
		Path:     path,
		Likes:    likes,
		Comments: comments,
		CommList: comL,
		CShow:    (comments != 0),
		Names:    namL,
		Tags:     tagC,
	}

	tmpl, err := template.ParseFiles("Templates/MyPost.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	err = tmpl.Execute(w, data)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	return
}

func ViewOtherPost(w http.ResponseWriter, r *http.Request, path string, uname string, cname string) {
	fmt.Println("In func " + path)
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	var likes, comments int
	var comlJ, namlJ, tagJ string
	var likJ string
	err = db.QueryRow("SELECT CommNo, Likes, Comments, CommentBy FROM Posts WHERE UserName = ? AND Path = ? LIMIT 1", cname, path).Scan(&comments, &likes, &comlJ, &namlJ)
	err = db.QueryRow("SELECT Tags FROM Posts WHERE UserName = ? AND Path = ?", cname, path).Scan(&tagJ)

	var comL, namL, tagL []string
	if comments != 0 {
		err = json.Unmarshal([]byte(comlJ), &comL)
		err = json.Unmarshal([]byte(namlJ), &namL)
	}
	err = json.Unmarshal([]byte(tagJ), &tagL)
	tagC := strings.Join(tagL, ",")
	lshow := false
	err = db.QueryRow("SELECT LikedBy FROM Posts WHERE UserName = ? AND Path = ?", cname, path).Scan(&likJ)
	if likJ != "" {
		var likL []string
		err = json.Unmarshal([]byte(likJ), &likL)
		if contains(likL, uname) {
			lshow = true
		}
	}

	data := OPostData{
		Path:     path,
		Likes:    likes,
		Comments: comments,
		CommList: comL,
		CShow:    (comments != 0),
		Names:    namL,
		Tags:     tagC,
		LShow:    lshow,
	}
	fmt.Println(lshow)

	tmpl, err := template.ParseFiles("Templates/OtherPost.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	err = tmpl.Execute(w, data)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	return
}

func Comment(w http.ResponseWriter, r *http.Request, uname string, cname string, path string) {
	err := r.ParseForm()
	comment := r.Form.Get("comment")
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	var Cno int
	var CmJ, CmBJ string
	err = db.QueryRow("SELECT CommNo, CommentBy, Comments FROM Posts WHERE UserName = ? AND Path = ?", cname, path).Scan(&Cno, &CmBJ, &CmJ)
	var CmL, CmBL []string

	if Cno != 0 {
		err = json.Unmarshal([]byte(CmJ), &CmL)
		err = json.Unmarshal([]byte(CmBJ), &CmBL)
	}
	CmL = append(CmL, comment)
	CmBL = append(CmBL, uname)

	Jbs, err := json.Marshal(CmL)
	query := "UPDATE Posts SET Comments = ? WHERE UserName = ? AND Path = ?"
	_, err = db.Exec(query, Jbs, cname, path)
	Jbs, err = json.Marshal(CmBL)
	query = "UPDATE Posts SET CommentBy = ? WHERE UserName = ? AND Path = ?"
	_, err = db.Exec(query, Jbs, cname, path)
	Cno++
	query = "UPDATE Posts SET CommNo = ? WHERE UserName = ? AND Path = ?"
	_, err = db.Exec(query, Cno, cname, path)
}

func Like(w http.ResponseWriter, r *http.Request, uname string, cname string, path string) {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	var likJ string
	err = db.QueryRow("SELECT Likes FROM Profiles WHERE UserName = ?", uname).Scan(&likJ)
	var likes int
	var likL []string
	err = db.QueryRow("SELECT Likes FROM Posts WHERE UserName = ? AND Path = ? LIMIT 1", cname, path).Scan(&likes)
	if likes != 0 {
		err = json.Unmarshal([]byte(likJ), &likL)
	}
	likL = append(likL, uname)
	likes++
	query := "UPDATE Posts SET Likes = ? WHERE UserName = ? AND Path = ?"
	_, err = db.Exec(query, likes, cname, path)

	likJS, err := json.Marshal(likL)
	query = "UPDATE Posts SET LikedBy = ? WHERE UserName = ? AND Path = ?"
	_, err = db.Exec(query, likJS, cname, path)
	ViewOtherPost(w, r, path, uname, cname)
}

func contains(s []string, str string) bool {
	for _, v := range s {
		if v == str {
			return true
		}
	}
	return false
}

func ViewFers(w http.ResponseWriter, r *http.Request, uname string) {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	//HERE
	var ListJ string
	var no int
	err = db.QueryRow("SELECT FollowersList FROM Profiles WHERE UserName = ? LIMIT 1", uname).Scan(&ListJ)
	err = db.QueryRow("SELECT Followers FROM Profiles WHERE UserName = ? LIMIT 1", uname).Scan(&no)

	var ListL []string
	if no != 0 {
		err = json.Unmarshal([]byte(ListJ), &ListL)
	}

	data := struct {
		People []string
		Text   string
		Show   bool
	}{
		People: ListL,
		Text:   uname + "'s followers",
		Show:   (no != 0),
	}

	tmpl := template.Must(template.ParseFiles("Templates/AllPeeps.html"))

	err = tmpl.Execute(w, data)
	if err != nil {
		panic(err)
	}
}

func ViewFing(w http.ResponseWriter, r *http.Request, uname string) {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	var ListJ string
	var no int
	err = db.QueryRow("SELECT FollowingList FROM Profiles WHERE UserName = ? LIMIT 1", uname).Scan(&ListJ)
	err = db.QueryRow("SELECT Following FROM Profiles WHERE UserName = ? LIMIT 1", uname).Scan(&no)

	var ListL []string
	if no != 0 {
		err = json.Unmarshal([]byte(ListJ), &ListL)
	}

	data := struct {
		People []string
		Text   string
		Show   bool
	}{
		People: ListL,
		Text:   "Accounts followed by " + uname,
		Show:   (no != 0),
	}

	tmpl := template.Must(template.ParseFiles("Templates/AllPeeps.html"))

	err = tmpl.Execute(w, data)
	if err != nil {
		panic(err)
	}
}

func Search(w http.ResponseWriter, r *http.Request) {
	err := r.ParseForm()
	tag := r.Form.Get("tag")
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

	var paths []string

	rows, err := db.Query("SELECT UserName, Path, Tags FROM Posts")
	if err != nil {
		panic(err.Error())
	}
	defer rows.Close()

	var uname, path, tagsJ string
	var tagsL []string
	var names []string
	for rows.Next() {
		err := rows.Scan(&uname, &path, &tagsJ)
		if err != nil {
			panic(err.Error())
		}
		err = json.Unmarshal([]byte(tagsJ), &tagsL)
		if contains(tagsL, tag) {
			paths = append(paths, path)
			names = append(names, uname)
		}
	}

	if err := rows.Err(); err != nil {
		panic(err.Error())
	}

	data := SearchData{
		Paths: paths,
		Names: names,
		Tag:   tag,
		Show:  (len(paths) != 0),
	}

	tmpl := template.Must(template.ParseFiles("Templates/PostList.html"))

	err = tmpl.Execute(w, data)
	if err != nil {
		panic(err)
	}
}

func Bookmark(w http.ResponseWriter, r *http.Request, uname string, cname string, path string) {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}

	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}

}
