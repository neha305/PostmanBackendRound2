package config

import (
	"golang.org/x/oauth2"
	"golang.org/x/oauth2/google"
)

func SetupConfig() *oauth2.Config {
	conf := &oauth2.Config{
		ClientID:     "162732932010-351r9p4advfhpsdf7d905lnnm8gjoek5.apps.googleusercontent.com",
		ClientSecret: "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",
		RedirectURL:  "http://localhost:8080/google/callback",
		Scopes: []string{
			"https://www.googleapis.com/auth/userinfo.email",
			"https://www.googleapis.com/auth/userinfo.profile",
		},
		Endpoint: google.Endpoint,
	}
	return conf
}
