package main

import (
	"fmt"
	"html/template"
	"myProj/controller"
	"myProj/doingshit"
	"myProj/profile"
	"myProj/users"
	"myProj/viewall"
	"net/http"
	"strings"

	//"github.com/gin-gonic/gin"
	_ "github.com/go-sql-driver/mysql"
)

var lIn bool
var lUn string
var cUn string

func main() {
	http.Handle("/PfpS/", http.StripPrefix("/PfpS/", http.FileServer(http.Dir("PfpS"))))
	http.Handle("/Posts/", http.StripPrefix("/Posts/", http.FileServer(http.Dir("Posts"))))
	http.HandleFunc("/google/login", controller.GoogleLogin)
	http.HandleFunc("/google/callback", controller.GoogleCallback)
	http.HandleFunc("/", HandlingFunc)
	http.ListenAndServe(":8080", nil)
}

func HandlingFunc(w http.ResponseWriter, r *http.Request) {
	if strings.Contains(r.URL.Path, "other") {
		cUn = r.URL.Path[strings.Index(r.URL.Path[1:], "/")+2:]
		r.URL.Path = r.URL.Path[:strings.Index(r.URL.Path[1:], "/")+1]
	}
	var path string
	if strings.Contains(r.URL.Path, "viewpost") {
		path = r.URL.Path[strings.Index(r.URL.Path[1:], "/")+2:]
		r.URL.Path = r.URL.Path[:strings.Index(r.URL.Path[1:], "/")+1]
	}
	if strings.Contains(r.URL.Path, "viewOpost") {
		if strings.Index(r.URL.Path, "/viewOpost") != 0 {
			cUn = r.URL.Path[1 : strings.Index(r.URL.Path[1:], "/")+1]
			r.URL.Path = r.URL.Path[strings.Index(r.URL.Path[1:], "/")+1:]
		}
		path = r.URL.Path[strings.Index(r.URL.Path[1:], "/")+2:]
		r.URL.Path = r.URL.Path[:strings.Index(r.URL.Path[1:], "/")+1]
	}
	if strings.Contains(r.URL.Path, "comment") {
		path = r.URL.Path[strings.Index(r.URL.Path[1:], "/")+2:]
		r.URL.Path = r.URL.Path[:strings.Index(r.URL.Path[1:], "/")+1]
	}
	if strings.Contains(r.URL.Path, "bookmark") {
		path = r.URL.Path[strings.Index(r.URL.Path[1:], "/")+2:]
		r.URL.Path = r.URL.Path[:strings.Index(r.URL.Path[1:], "/")+1]
	}
	if strings.Contains(r.URL.Path, "like") {
		path = r.URL.Path[strings.Index(r.URL.Path[1:], "/")+2:]
		r.URL.Path = r.URL.Path[:strings.Index(r.URL.Path[1:], "/")+1]
	}

	switch r.URL.Path {
	case "/":
		if lIn {
			getHomePage(w, r)
		} else {
			http.ServeFile(w, r, "Templates/Sup.html")
		}
	case "/SignUp.html":
		getSignUpPage(w, r)
	case "/Login.html":
		getLoginPage(w, r)
	case "/sign-in":
		signInUser(w, r)
	case "/sign-up":
		signUpUser(w, r)
	case "/profile":
		getProfile(w, r)
	case "/logout":
		lIn = false
		lUn = ""
		fmt.Println("Logout successful")
		http.ServeFile(w, r, "Templates/Sup.html")
	case "/viewall":
		fmt.Println("View ALl")
		viewAll(w, r)
	case "/other":
		fmt.Println("View other")
		fmt.Println(cUn)
		if cUn == lUn {
			getProfile(w, r)
		} else {
			getOtherProfile(w, r)
		}
	case "/addpfp":
		http.ServeFile(w, r, "Templates/AddPfp.html")
	case "/uploadpfp":
		profile.Upload(w, r, lUn)
		getProfile(w, r)
	case "/follow":
		doingshit.Follow(w, r, lUn, cUn)
		getOtherProfile(w, r)
	case "/newpost":
		http.ServeFile(w, r, "Templates/AddPost.html")
	case "/uploadpost":
		doingshit.NewPost(w, r, lUn)
		getProfile(w, r)
	case "/viewpost":
		doingshit.ViewMyPost(w, r, path, lUn)
	case "/viewOpost":
		if lUn == cUn {
			doingshit.ViewMyPost(w, r, path, lUn)
		} else {
			doingshit.ViewOtherPost(w, r, path, lUn, cUn)
		}
	case "/comment":
		doingshit.Comment(w, r, lUn, cUn, path)
		doingshit.ViewOtherPost(w, r, path, lUn, cUn)
	case "/like":
		doingshit.Like(w, r, lUn, cUn, path)
	case "/vfer":
		doingshit.ViewFers(w, r, lUn)
	case "/vfing":
		doingshit.ViewFing(w, r, lUn)
	case "/vferO":
		doingshit.ViewFers(w, r, cUn)
	case "/vfingO":
		doingshit.ViewFing(w, r, cUn)
	case "/search":
		doingshit.Search(w, r)
	case "/bookmark":
		doingshit.Bookmark(w, r, lUn, cUn, path)
	}
}

func getOtherProfile(w http.ResponseWriter, r *http.Request) {
	profile.OSetting(w, r, lUn, cUn)
}

func viewAll(w http.ResponseWriter, r *http.Request) {
	viewall.ViewAll(w, r, lUn)
}

func getProfile(w http.ResponseWriter, r *http.Request) {
	profile.Setting(w, r, lUn)
}

func getSignUpPage(w http.ResponseWriter, r *http.Request) {
	http.ServeFile(w, r, "Templates/SignUp.html")
}

func getLoginPage(w http.ResponseWriter, r *http.Request) {
	http.ServeFile(w, r, "Templates/Login.html")
}

func signInUser(w http.ResponseWriter, r *http.Request) {
	fmt.Println("HELLO hopefully logging in pls wait")
	newUser := getUser(r)
	ok := users.DefaultUserService.VerifyUser(newUser)

	switch ok {
	case 0:
		fmt.Println("Wrong password")
		getLoginPage(w, r)
	case 1:
		fmt.Println("Logged in lessgooo")
		fmt.Println("Please Find Below Your Username")
		fmt.Println(newUser.Uname)
		lUn = newUser.Uname
		lIn = true
		getHomePage(w, r)
	case 2:
		getLoginPage(w, r)
	}
}

func signUpUser(w http.ResponseWriter, r *http.Request) {
	newUser := getUser(r)
	err := users.DefaultUserService.CreateUser(newUser)
	fmt.Println("Created new user")
	if err != nil {
		fmt.Println(err)
		//Sign up error
		getSignUpPage(w, r)
	}
	fmt.Println("Sign up done")
	getLoginPage(w, r)
}

func getUser(r *http.Request) users.User {
	uname := r.FormValue("uname")
	psw := r.FormValue("psw")
	return users.User{
		Uname: uname,
		Psw:   psw,
	}
}

func getHomePage(w http.ResponseWriter, r *http.Request) {
	type homeData struct {
		Uname string
	}
	data := homeData{
		Uname: lUn,
	}

	tmpl, err := template.ParseFiles("Templates/Home.html")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	err = tmpl.Execute(w, data)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

}
