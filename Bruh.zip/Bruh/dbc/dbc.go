// Not using this but I don't want to delete it out of fear of breaking something
package dbc

import (
	"database/sql"
	//"log"
	"fmt"

	_ "github.com/go-sql-driver/mysql"
)

var db *sql.DB

func init() {
	db, err := sql.Open("mysql", "root:neha_Mysql3@tcp(localhost:3306)/ThankFuck")
	fmt.Println("Db connected")
	if err != nil {
		fmt.Println("Errorin sql.Open")
		panic(err.Error())
	}
	defer db.Close()

	err = db.Ping()
	if err != nil {
		fmt.Println("Errorin db.Ping")
		panic(err.Error())
	}
}
